package com.example.mobilecookbook

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment

class Recipelist : Fragment() {

    private lateinit var recipeListView: ListView
    private lateinit var addRecipeButton: Button
    private lateinit var ratingBar: RatingBar

    private val recipeList = mutableListOf<Pair<String, Float>>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_recipelist, container, false)

        // Znalezienie widoków
        recipeListView = view.findViewById(R.id.recipeListView)
        addRecipeButton = view.findViewById(R.id.addRecipeButton)
        ratingBar = view.findViewById(R.id.ratingBar)


        val adapter = RecipeAdapter(recipeList)
        recipeListView.adapter = adapter

        addRecipeButton.setOnClickListener {
            val newRecipe = editText.text.toString()
            val newRating = ratingBar.rating

            recipeList.add(Pair(newRecipe, newRating))

            adapter.notifyDataSetChanged()

            ratingBar.rating = 0f
        }

        return view
    }

    inner class RecipeAdapter(private val recipes: List<Pair<String, Float>>) : BaseAdapter() {

        override fun getCount(): Int = recipes.size
        override fun getItem(position: Int): Any = recipes[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val view: View
            val viewHolder: ViewHolder

            if (convertView == null) {
                val inflater = LayoutInflater.from(requireContext())
                view = inflater.inflate(R.layout.recipe_item, parent, false)

                viewHolder = ViewHolder(
                    view.findViewById(R.id.recipeName),
                    view.findViewById(R.id.ratingBar)
                )
                view.tag = viewHolder
            } else {
                view = convertView
                viewHolder = view.tag as ViewHolder
            }

            val recipe = recipes[position]

            viewHolder.recipeName.text = recipe.first
            viewHolder.ratingBar.rating = recipe.second

            return view
        }
    }

    // ViewHolder przechowujący widoki
    private class ViewHolder(val recipeName: TextView, val ratingBar: RatingBar)
}
